'use client'; // Ensures this is a Client Component

import React, { useState } from 'react';
import QRCode from 'qrcode';
import { useForm } from 'react-hook-form';

interface FormData {
    inputText: string;
}

const QRCodeGenerator: React.FC = () => {
    const { register, handleSubmit } = useForm<FormData>();
    const [qrCodeUrl, setQrCodeUrl] = useState<string | null>(null);

    const generateQRCode = async (data: FormData) => {
        if (!data.inputText) {
            alert("Please enter some text to generate a QR code.");
            return;
        }

        try {
            const url = await QRCode.toDataURL(data.inputText);
            setQrCodeUrl(url);
        } catch (err) {
            console.error(err);
        }
    };

    return (
        <div className="container">
            <h1 className="title">QR Code Generator</h1>

            <form onSubmit={handleSubmit(generateQRCode)} className="form">
                <input
                    type="text"
                    id="inputText"
                    className="input"
                    placeholder="Enter any text..."
                    {...register('inputText')}
                />

                <button type="submit" className="submit-button">Create QR Code</button>
            </form>

            {qrCodeUrl && (
                <div className="qr-code-container">
                    <h2>Your QR Code:</h2>
                    <img src={qrCodeUrl} alt="Generated QR Code" className="qr-image" />
                </div>
            )}

            <style jsx>{`
                .container {
                    max-width: 700px;
                    margin: 0 auto;
                    padding: 50px 20px;
                    text-align: center;
                    background-color: #f9f9f9;
                    border-radius: 12px;
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
                }

                .title {
                    font-size: 2.5rem;
                    margin-bottom: 20px;
                    color: #333;
                }

                .form {
                    display: flex;
                    justify-content: center;
                    margin-bottom: 30px;
                }

                .input {
                    padding: 12px;
                    font-size: 1.2rem;
                    width: 70%;
                    border: 2px solid #ccc;
                    border-radius: 8px;
                    margin-right: 10px;
                    outline: none;
                    transition: border-color 0.3s ease;
                }

                .input:focus {
                    border-color: #0070f3;
                }

                .submit-button {
                    padding: 12px 20px;
                    background-color: #0070f3;
                    color: white;
                    border: none;
                    border-radius: 8px;
                    font-size: 1.2rem;
                    cursor: pointer;
                    transition: background-color 0.3s ease;
                }

                .submit-button:hover {
                    background-color: #005bb5;
                }

                .qr-code-container {
                    margin-top: 20px;
                }

                .qr-code-container h2 {
                    font-size: 1.8rem;
                    margin-bottom: 10px;
                }

                .qr-image {
                    margin-top: 10px;
                    max-width: 250px;
                    height: auto;
                    border: 5px solid #0070f3;
                    border-radius: 10px;
                }
            `}</style>
        </div>
    );
};

export default QRCodeGenerator;
